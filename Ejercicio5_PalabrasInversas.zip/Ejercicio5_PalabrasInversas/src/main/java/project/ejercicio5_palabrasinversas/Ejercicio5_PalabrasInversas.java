/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.ejercicio5_palabrasinversas;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio5_PalabrasInversas {

    public static void main(String[] args) {
     System.out.println("(Usando FOR)");
     HechoConFor();
     System.out.println("");
     System.out.println("Usando while:");
     HechoConWhile();
      System.out.println("");
     System.out.println("Usando Dowhile:");
     HechoConDoWhile();
     
     

    }
    public static void HechoConFor(){
        Scanner input = new Scanner(System.in);
        input.useDelimiter("\n");
        String word = "";

       
        System.out.println("Escribe una palabra: ");
        word = input.next();
        System.out.println("");

        System.out.print("El reverso de la palabra es: ");
        for(int i=word.length();i>0;i--){
        System.out.print(word.charAt(i-1));
        }
        System.out.println("");
    }
    public static void HechoConWhile(){
       Scanner input = new Scanner(System.in);
    input.useDelimiter("\n");
    String word = "";

    System.out.println("Invertir palabra (Usando WHILE)");
    System.out.println("Ingrese una palabra: ");
    word = input.next();
    System.out.println("");

    System.out.print("El reverso de la palabra es: ");
    int i = word.length();
    while (i > 0) {
    System.out.print(word.charAt(i-1));
    i--;
    }
    System.out.println(""); 
    }
    public static void HechoConDoWhile(){
     Scanner input = new Scanner(System.in);
    input.useDelimiter("\n");
    String word = "";

        System.out.println("Invertir palabras (Usando DO-WHILE)");
        System.out.println("Ingrese una palabra: ");
        word = input.next();
        System.out.println("");

        System.out.print("La palabra invertida es: ");
        int i = word.length();
        do {
            System.out.print(word.charAt(i - 1));
            i--;
        } while (i > 0);
        System.out.println("");
    }
}

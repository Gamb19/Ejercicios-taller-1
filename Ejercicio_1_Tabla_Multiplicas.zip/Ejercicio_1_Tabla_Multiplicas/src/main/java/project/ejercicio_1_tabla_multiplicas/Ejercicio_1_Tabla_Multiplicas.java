/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.ejercicio_1_tabla_multiplicas;

/**
 *
 * @author molin
 */
public class Ejercicio_1_Tabla_Multiplicas {

    public static void main(String[] args) {
        int Numero1 = (int)Math.floor(Math.random()*10+1); 
        int Numero2 = (int)Math.floor(Math.random()*10+1); 
        int z=0;
        int x=0;
        int [] multi = new int [Numero2 + 1];
       System.out.println("Multiplicando: "+ Numero1);
       System.out.println("Multiplicador: " + Numero2);
       System.out.println("Hecho con for:");
      for(int i=1; i<=Numero2; i++){
           System.out.println(Numero1 + " * " + i + " = " + Numero1*i);                                                     
       }
      System.out.println("");
    System.out.println("");
    System.out.println("Hecho con Do while:");
 
     do{ 
      z++;
      System.out.println(Numero1 + " * " +z+ " = " + Numero1*z);  
         
       }while(z<Numero2);
     
     System.out.println("");
    System.out.println("");
    System.out.println("Hecho con While:");
    
     while(x<Numero2){
         x++;
         System.out.println(Numero1 + " * " +x+ " = " + Numero1*x); 
     }
     
     System.out.println("");
    System.out.println("");
    System.out.println("Hecho con for each:");
    
    for (int y=0; y<=Numero2; y++){
        multi[y]=y;
    }
    for(int array:multi){
        System.out.println(Numero1 + " * " +array+ " = " + Numero1*array);
    }
     
    }
 }

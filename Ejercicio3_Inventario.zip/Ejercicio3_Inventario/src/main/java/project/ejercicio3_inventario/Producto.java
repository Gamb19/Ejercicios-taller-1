/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.ejercicio3_inventario;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio3_Inventario {

    public static void main(String[] args) {
       System.out.println("Hecho con for: ");
      doneWithFor();
       System.out.println(" ");
       System.out.println(" ");
       System.out.println(" ");
       System.out.println("Hecho con Do while: ");z
    }
    public static void doneWithFor(){
     Scanner sc = new Scanner(System.in);
        int numProductos = (int) Math.floor(Math.random() * 10 + 1);
        System.out.print("Puedes ingresar: "+ numProductos);
        
        
        // Crear un array de productos
        Producto[] inventario = new Producto[numProductos];
        
        // Pedir al usuario que ingrese los detalles de cada producto
        for (int i = 0; i < numProductos; i++) {
            System.out.print("\nIngrese el nombre del producto " + (i+1) + ": ");
            String nombre = sc.next();
            
            System.out.print("Ingrese el precio del producto " + (i+1) + ": ");
            double precio = sc.nextDouble();
            
            System.out.print("Ingrese la cantidad del producto " + (i+1) + ": ");
            int cantidad = sc.nextInt();
            
            // Crear un objeto de Producto y agregarlo al array
            inventario[i] = new Producto(nombre, precio, cantidad);
        }
        
        // Imprimir la lista de productos ingresados
        System.out.println("\n\nLista de productos ingresados:");
        for (int i = 0; i < numProductos; i++) {
            System.out.println(inventario[i].toString());
        }
        
        sc.close();
    }
}

class Producto {
    
    private String nombre;
    private double precio;
    private int cantidad;
    
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public double getPrecio() {
        return precio;
    }
    
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    public int getCantidad() {
        return cantidad;
    }
    
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    @Override
    public String toString() {
        return "Producto: " + nombre + " / Precio: " + precio + " / Cantidad: " + cantidad;
    }
    
    public static void doneWithdoWhile(){
                Scanner sc = new Scanner(System.in);
        int numProductos;
        do {
            numProductos = (int) Math.floor(Math.random() * 10 + 1);
        } while (numProductos < 1);

        System.out.print("Puedes ingresar: "+ numProductos);

        Producto[] inventario = new Producto[numProductos];

        int i = 0;
        do {
            System.out.print("\nIngrese el nombre del producto " + (i+1) + ": ");
            String nombre = sc.next();

            System.out.print("Ingrese el precio del producto " + (i+1) + ": ");
            double precio = sc.nextDouble();

            System.out.print("Ingrese la cantidad del producto " + (i+1) + ": ");
            int cantidad = sc.nextInt();

            inventario[i] = new Producto(nombre, precio, cantidad);

            i++;
        } while (i < numProductos);

        System.out.println("\n\nLista de productos ingresados:");
        for (int j = 0; j < numProductos; j++) {
            System.out.println(inventario[j].toString());
        }

        sc.close();
    }
    }


    


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.ejercicio4_palabraraiz;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio4_Palabraraiz {

    public static void main(String[] args) {
         System.out.println("Hecho con For:");
         doneWithFor();
         System.out.println();
         System.out.println();
         System.out.println();
         System.out.println("Hecho con Do While:");
         doneWithDoWhile();
         System.out.println();
         System.out.println();
         System.out.println();
         System.out.println("Hecho con While");
         doneWithWhile();
         System.out.println();
         System.out.println();
         System.out.println();
         System.out.println("Hecho con For each");
         doneWithForEach();
         
    }
    public static void doneWithFor(){
        Scanner entrada = new Scanner(System.in);
            System.out.println("Ingresa la palabra raiz: ");
            String palabraBase = entrada.nextLine();

            // Pedir al usuario que ingrese 4 palabras adicionales y almacenarlas en un arreglo
            System.out.println("Ingresa las otras 4 palabras: ");
            String[] palabrasAdicionales = new String[4];
            for (int i = 0; i < 4; i++) {
            palabrasAdicionales[i] = entrada.nextLine();
            }
                    int i = 0;
            // Comprobar si la palabra adicional se puede formar con las letras de la palabra base
            for (int j = 0; j < palabrasAdicionales[i].length(); j++) {
                if (palabraBase.contains(String.valueOf(palabrasAdicionales[i].charAt(j)))) {
                    System.out.println("La palabra " + palabrasAdicionales[i] + " se puede unir en la palabra base");
                    break;
                }
}  
    }
    public static void doneWithForEach(){
        Scanner entrada = new Scanner(System.in);


                System.out.println("Ingresa la palabra raiz: ");
                String palabraBase = entrada.nextLine();


                System.out.println("Ingresa las otras 4 palabras: ");
                String[] palabrasAdicionales = new String[4];
                for (int i = 0; i < 4; i++) {
                palabrasAdicionales[i] = entrada.nextLine();
                }


                for (String palabraAdicional : palabrasAdicionales) {
                for (int i = 0; i < palabraAdicional.length(); i++) {
                if (palabraBase.contains(String.valueOf(palabraAdicional.charAt(i)))) {
                System.out.println("La palabra " + palabraAdicional + " se puede unir en la palabra base");
                break;
        }
}
}
    }
    public static void doneWithDoWhile(){
         Scanner entrada = new Scanner(System.in);
         System.out.println("Ingresa la palabra raiz: ");
        String palabraBase = entrada.nextLine();

        // Pedir al usuario que ingrese 4 palabras adicionales y almacenarlas en un arreglo
        System.out.println("Ingresa las otras 4 palabras: ");
        String[] palabrasAdicionales = new String[4];
        int i = 0;
        do {
            palabrasAdicionales[i] = entrada.nextLine();
            i++;
        } while (i < 4);

        // Buscar si cada palabra adicional se puede formar con las letras de la palabra base
        int j = 0;
        do {
            for (int k = 0; k < palabrasAdicionales[j].length(); k++) {
                if (palabraBase.contains(String.valueOf(palabrasAdicionales[j].charAt(k)))) {
                    System.out.println("La palabra " + palabrasAdicionales[j] + " se puede unir en la palabra base");
                    break;
                }
            }
            j++;
        } while (j < palabrasAdicionales.length);
    
    }
    public static void doneWithWhile(){
        Scanner entrada = new Scanner(System.in);
            System.out.println("Ingresa la palabra raiz: ");
            String palabraBase = entrada.nextLine();
            System.out.println("Ingresa las otras 4 palabras: ");
            String[] palabras = new String[4];
            for (int i = 0; i < 4; i++) {
                palabras[i] = entrada.nextLine();
            }
            int i = 0;
            while (i < palabras.length) {
                int j = 0;
                while (j < palabras[i].length()) {
                    if (palabraBase.contains(String.valueOf(palabras[i].charAt(j)))) {
                        System.out.println("La palabra " + palabras[i] + " se puede unir  en la palabra base");
                        break;
                    }
                    j++;
                }
                i++;
            }
    }
}

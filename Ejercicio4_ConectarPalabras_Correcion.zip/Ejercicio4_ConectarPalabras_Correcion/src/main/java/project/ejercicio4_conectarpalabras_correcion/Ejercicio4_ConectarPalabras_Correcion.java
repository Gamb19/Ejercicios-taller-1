/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.ejercicio4_conectarpalabras_correcion;

import java.util.Scanner;

/**
 *
 * @author molin
 */
public class Ejercicio4_ConectarPalabras_Correcion {

    public static void main(String[] args) {
       System.out.println("Hecho con for: ");
     HechoConFor();
     System.out.println();
     System.out.println();
     System.out.println();
     System.out.println("Hecho con While: ");
     HechoConWhile();
     System.out.println();
     System.out.println();
     System.out.println();
     System.out.println("Hecho con Do While: ");
     HechoConDoWhile();
    }
     
    public static void HechoConFor(){
            Scanner entrada = new Scanner(System.in);
        String[] palabras = new String[5];
        boolean cruzo;

        System.out.println("Ingrese 5 palabras para encajar: ");
        for (int i = 0; i < 5; i++) {
            System.out.print((i + 1) + ": ");
            palabras[i] = entrada.next();
        }

        for (int h = 0; h < 5; h++) {

            int[] validador = new int[palabras[h].length()];

            for (int i = 0; i < palabras[h].length(); i++) {
                validador[i] = 0;
            }
            System.out.println("Palabra Raíz: " + palabras[h]);

            for (int i = 0; i < 5; i++) {

                if (h == i) {
                    continue;
                }

                for (int j = 0; j < palabras[h].length(); j++) {

                    cruzo = false;

                    for (int k = 0; k < palabras[i].length(); k++) {

                        if (palabras[i].charAt(k) == palabras[h].charAt(j) && validador[j] != 1) {

                            System.out.println("Match: " + palabras[i].charAt(k) + " y " + palabras[h].charAt(j) + " de las palabras " + palabras[h].toUpperCase() + " y " + palabras[i].toUpperCase());
                            cruzo = true;
                            break;
                        }
                    }

                    if (cruzo) {
                        validador[j] = 1;
                        break;
                    }

                }
            }
        }

    }  
    public static void HechoConWhile(){
    Scanner entrada = new Scanner(System.in);
        String[] palabras = new String[5];
        boolean cruzo;

        System.out.println("Ingrese 5 palabras para encajar: ");
        int i = 0;
        while (i < 5) {
            System.out.print((i + 1) + ": ");
            palabras[i] = entrada.next();
            i++;
        }

        int h = 0;
        while (h < 5) {

            int[] validador = new int[palabras[h].length()];

            i = 0;
            while (i < palabras[h].length()) {
                validador[i] = 0;
                i++;
            }
            System.out.println("Palabra Raíz: " + palabras[h]);

             i = 0;
            while (i < 5) {

                if (h == i) {
                    i++;
                    continue;
                }

                int j = 0;
                while (j < palabras[h].length()) {

                    cruzo = false;

                    int k = 0;
                    while (k < palabras[i].length()) {

                        if (palabras[i].charAt(k) == palabras[h].charAt(j) && validador[j] != 1) {

                            System.out.println("Encaja: " + palabras[i].charAt(k) + " y " + palabras[h].charAt(j) + " de las palabras " + palabras[h].toUpperCase() + " y " + palabras[i].toUpperCase());
                            cruzo = true;
                            break;
                        }
                        k++;
                    }

                    if (cruzo) {
                        validador[j] = 1;
                        break;
                    }
                    j++;
                }
                i++;
            }
            h++;
        }

            }
    public static void HechoConDoWhile(){
        Scanner entrada = new Scanner(System.in);
            String[] palabras = new String[5];
            boolean cruzo;

            System.out.println("Ingrese 5 palabras para encajar: ");
            int i = 0;
            do {
                System.out.print((i + 1) + ": ");
                palabras[i] = entrada.next();
                i++;
            } while (i < 5);

            int h = 0;
            do {

                int[] validador = new int[palabras[h].length()];

                i = 0;
                do {
                    validador[i] = 0;
                    i++;
                } while (i < palabras[h].length());
                System.out.println("Palabra Raíz: " + palabras[h]);

                i = 0;
                do {

                    if (h == i) {
                        i++;
                        continue;
                    }

                    int j = 0;
                    do {

                        cruzo = false;

                        int k = 0;
                        do {

                            if (palabras[i].charAt(k) == palabras[h].charAt(j) && validador[j] != 1) {

                                System.out.println("Encaja: " + palabras[i].charAt(k) + " y " + palabras[h].charAt(j) + " de las palabras " + palabras[h].toUpperCase() + " y " + palabras[i].toUpperCase());
                                cruzo = true;
                                break;
                            }
                            k++;
                        } while (k < palabras[i].length());

                        if (cruzo) {
                            validador[j] = 1;
                            break;
                        }
                        j++;
                    } while (j < palabras[h].length());

                    i++;
                } while (i < 5);

                h++;
            } while (h < 5);
    }
}

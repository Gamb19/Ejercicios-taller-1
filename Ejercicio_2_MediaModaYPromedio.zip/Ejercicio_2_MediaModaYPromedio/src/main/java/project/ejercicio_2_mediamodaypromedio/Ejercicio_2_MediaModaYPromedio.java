/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package project.ejercicio_2_mediamodaypromedio;

import java.util.*;

/**
 *
 * @author molin
 */
public class Ejercicio_2_MediaModaYPromedio {
 
       
    public static void main(String[] args) {
        System.out.println("Hecho con for:");
        doneWithFor();
        
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.println("Hecho con while:");
        DoneWithWhile();
        
         System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.println("Hecho con Do while:");
        doneWithDoWhile();
        
         System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.println("Hecho con For each:");
        doneWithForEach();
    }
     public static void doneWithFor(){
       int randomNum = (int) Math.floor(Math.random() * 28 + 1);
        int Valores;
        double media;
        double suma = 0;
        double mediana;
        int mitad;
        double moda = 0;
        int maxValue = 0;
        int[] arrMediana = new int[randomNum];
        int[] arrModa = new int[randomNum];
        Scanner lector = new Scanner(System.in);
        System.out.println("Su numero aleatorio, es el: " + randomNum);
        for (int i = 0; i < randomNum; i++) {
            System.out.println("Ingrese su valor # " + (i + 1) + ": ");
            Valores = lector.nextInt();
            suma = suma + Valores;
            arrMediana[i] = Valores;
            arrModa[i] = Valores;
        }
//   Proceso media 
        media = suma / randomNum;
//   Proceso Mediana
        Arrays.sort(arrMediana);
        mitad = arrMediana.length / 2;
        // Si la longitud es par, se deben promediar los del centro
        if (arrMediana.length % 2 == 0) {
            mediana = (arrMediana[mitad - 1] + arrMediana[mitad]) / 2;
        } else {
            mediana = arrMediana[mitad];
        }
//   Proceso Moda
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int y : arrModa) {
            if (map.containsKey(y)) {
                int contador = map.get(y) + 1;
                map.put(y, contador);
                if (contador > maxValue) {
                    moda = y;
                    maxValue = contador;
                }
            } else {
                map.put(y, 1);
            }
        }
        System.out.println("HECHO CON FOR:");
        System.out.println("La media de sus numeros es: " + media);
        System.out.println("La mediana de sus numeros es: " + mediana);
        System.out.println("La modas son:" + map + "Y la moda en general es: " + moda);
        }   

        public static void DoneWithWhile(){
            int randomNum = (int) Math.floor(Math.random() * 28 + 1);
          int Valores;
          double media;
          double suma = 0;
          double mediana;
          int mitad;
          double moda = 0;
          int maxValue = 0;
          int[] arrMediana = new int[randomNum];
          int[] arrModa = new int[randomNum];
          Scanner lector = new Scanner(System.in);
          System.out.println("Su numero aleatorio, es el: " + randomNum);

          int i = 0;
          while (i < randomNum) {
          System.out.println("Ingrese su valor # " + (i + 1) + ": ");
          Valores = lector.nextInt();
          suma = suma + Valores;
          arrMediana[i] = Valores;
          arrModa[i] = Valores;
          i++;
      }

        //   Proceso media 
        media = suma / randomNum;

        //   Proceso Mediana
        Arrays.sort(arrMediana);
        mitad = arrMediana.length / 2;
        // Si la longitud es par, se deben promediar los del centro
        if (arrMediana.length % 2 == 0) {
            mediana = (arrMediana[mitad - 1] + arrMediana[mitad]) / 2;
        } else {
            mediana = arrMediana[mitad];
        }

        //   Proceso Moda
        HashMap<Integer, Integer> map = new HashMap<>();
        int y = 0;
        while (y < arrModa.length) {
            if (map.containsKey(arrModa[y])) {
                int contador = map.get(arrModa[y]) + 1;
                map.put(arrModa[y], contador);
                if (contador > maxValue) {
                    moda = arrModa[y];
                    maxValue = contador;
                }
            } else {
                map.put(arrModa[y], 1);
            }
            y++;
        }

        System.out.println("HECHO CON WHILE:");
        System.out.println("La media de sus numeros es: " + media);
        System.out.println("La mediana de sus numeros es: " + mediana);
        System.out.println("La modas son:" + map + "Y la moda en general es: " + moda);
        
  }
       public static void doneWithDoWhile(){
           int randomNum = (int) Math.floor(Math.random() * 28 + 1);
        double media;
        double suma = 0;
        double mediana;
        int mitad;
        double moda = 0;
        int maxValue = 0;
        int[] arrMediana = new int[randomNum];
        int[] arrModa = new int[randomNum];
        Scanner lector = new Scanner(System.in);
        System.out.println("Su numero aleatorio, es el: " + randomNum);

        int i = 0;
        do {
            System.out.println("Ingrese su valor # " + (i + 1) + ": ");
            int Valores = lector.nextInt();
            suma = suma + Valores;
            arrMediana[i] = Valores;
            arrModa[i] = Valores;
            i++;
        } while (i < randomNum);

        // Proceso media 
        media = suma / randomNum;

        // Proceso Mediana
        Arrays.sort(arrMediana);
        mitad = arrMediana.length / 2;
        // Si la longitud es par, se deben promediar los del centro
        if (arrMediana.length % 2 == 0) {
            mediana = (arrMediana[mitad - 1] + arrMediana[mitad]) / 2;
        } else {
            mediana = arrMediana[mitad];
        }

        // Proceso Moda
        HashMap<Integer, Integer> map = new HashMap<>();
        int y = 0;
        do {
            if (map.containsKey(arrModa[y])) {
                int contador = map.get(arrModa[y]) + 1;
                map.put(arrModa[y], contador);
                if (contador > maxValue) {
                    moda = arrModa[y];
                    maxValue = contador;
                }
            } else {
                map.put(arrModa[y], 1);
            }
            y++;
        } while (y < arrModa.length);

        System.out.println("HECHO CON DO-WHILE:");
        System.out.println("La media de sus numeros es: " + media);
        System.out.println("La mediana de sus numeros es: " + mediana);
        System.out.println("La modas son: " + map + " Y la moda en general es: " + moda);
       }
       public static void doneWithForEach(){
          int randomNum = (int) Math.floor(Math.random() * 28 + 1);
        int Valores;
        double media;
        double suma = 0;
        double mediana;
        int mitad;
        double moda = 0;
        int maxValue = 0;
        int[] arrMediana = new int[randomNum];
        int[] arrModa = new int[randomNum];
        Scanner lector = new Scanner(System.in);
        System.out.println("Su numero aleatorio, es el: " + randomNum);
        int i = 0;
        for (int num : arrMediana) {
            System.out.println("Ingrese su valor # " + (i + 1) + ": ");
            Valores = lector.nextInt();
            suma = suma + Valores;
            arrMediana[i] = Valores;
            arrModa[i] = Valores;
            i++;
        }
        // Proceso media 
        media = suma / randomNum;
        // Proceso Mediana
        Arrays.sort(arrMediana);
        mitad = arrMediana.length / 2;
        // Si la longitud es par, se deben promediar los del centro
        if (arrMediana.length % 2 == 0) {
            mediana = (arrMediana[mitad - 1] + arrMediana[mitad]) / 2;
        } else {
            mediana = arrMediana[mitad];
        }
        // Proceso Moda
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int num : arrModa) {
            if (map.containsKey(num)) {
                int contador = map.get(num) + 1;
                map.put(num, contador);
                if (contador > maxValue) {
                    moda = num;
                    maxValue = contador;
                }
            } else {
                map.put(num, 1);
            }
        }
        System.out.println("HECHO CON FOR-EACH:");
        System.out.println("La media de sus numeros es: " + media);
        System.out.println("La mediana de sus numeros es: " + mediana);
        System.out.println("La modas son:" + map + "Y la moda en general es: " + moda); 
           
       }
    }
    

